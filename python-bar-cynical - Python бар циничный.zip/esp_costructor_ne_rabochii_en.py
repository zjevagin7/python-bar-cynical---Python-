# site_builder_en.py
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox, colorchooser
import json
import os
import glob
import tempfile
import webbrowser
import sys

class ESP8266SiteBuilder:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("ESP Site Builder - Sanchez's Cynical Constructor")
        self.root.geometry("450x700")
        self.root.resizable(True, True)
        self.root.minsize(450, 700)
        
        # Set window icon
        try:
            self.root.iconbitmap("app_icon.ico")
        except:
            try:
                if getattr(sys, 'frozen', False):
                    base_path = sys._MEIPASS
                else:
                    base_path = os.path.dirname(__file__)
                icon_path = os.path.join(base_path, "app_icon.ico")
                self.root.iconbitmap(icon_path)
            except:
                pass
        
        self.config_file = "site_builder_config.json"
        self.load_config()
        
        self.setup_ui()
    
    def load_config(self):
        default_config = {
            'colors': {
                'bg': '#0a0a0a',
                'primary': '#8b0000', 
                'secondary': '#696969',
                'accent': '#b22222',
                'text': '#d3d3d3'
            },
            'wifi': {
                'ssid': 'your_network',
                'password': 'your_password',
                'ip': '192.168.1.100',
                'use_dhcp': False
            },
            'export_path': os.getcwd(),
            'content': []
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                self.colors = config.get('colors', default_config['colors'])
                self.wifi_config = config.get('wifi', default_config['wifi'])
                self.export_path = config.get('export_path', default_config['export_path'])
                self.current_content = config.get('content', [])
            else:
                self.colors = default_config['colors']
                self.wifi_config = default_config['wifi']
                self.export_path = default_config['export_path']
                self.current_content = []
                self.save_config()
        except Exception as e:
            print(f"Config load error: {e}")
            self.colors = default_config['colors']
            self.wifi_config = default_config['wifi']
            self.export_path = default_config['export_path']
            self.current_content = []
    
    def save_config(self):
        config = {
            'colors': self.colors,
            'wifi': self.wifi_config,
            'export_path': self.export_path,
            'content': self.current_content
        }
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Config save error: {e}")
    
    def setup_ui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.setup_builder_tab()
        self.setup_preview_tab()
        self.setup_code_tab()
    
    def setup_builder_tab(self):
        builder_frame = ttk.Frame(self.notebook)
        self.notebook.add(builder_frame, text="🍷 Builder")
        
        main_container = tk.Frame(builder_frame, bg=self.colors['bg'])
        main_container.pack(fill=tk.BOTH, expand=True)
        
        self.canvas = tk.Canvas(main_container, bg=self.colors['bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_container, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=self.colors['bg'])
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.canvas.bind("<Enter>", self._bind_mouse)
        self.canvas.bind("<Leave>", self._unbind_mouse)
        
        self.setup_components_section()
        self.setup_color_picker()
        self.setup_content_editor()
        self.setup_export_section()
    
    def setup_preview_tab(self):
        preview_frame = ttk.Frame(self.notebook)
        self.notebook.add(preview_frame, text="👁️ Preview")
        
        preview_controls = ttk.Frame(preview_frame)
        preview_controls.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(preview_controls, text="🔄 Update Preview", 
                  command=self.update_preview).pack(side=tk.LEFT, padx=2)
        ttk.Button(preview_controls, text="🌐 Open in Browser", 
                  command=self.open_in_browser).pack(side=tk.LEFT, padx=2)
        ttk.Button(preview_controls, text="💾 Save HTML", 
                  command=self.save_html_file).pack(side=tk.LEFT, padx=2)
        
        preview_container = ttk.Frame(preview_frame)
        preview_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.preview_text = scrolledtext.ScrolledText(preview_container, wrap=tk.WORD, 
                                                     font=('Arial', 10))
        self.preview_text.pack(fill=tk.BOTH, expand=True)
        
        self.update_preview()
    
    def setup_code_tab(self):
        code_frame = ttk.Frame(self.notebook)
        self.notebook.add(code_frame, text="⚡ Arduino Code")
        
        code_controls = ttk.Frame(code_frame)
        code_controls.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(code_controls, text="🔄 Update Code", 
                  command=self.update_arduino_code).pack(side=tk.LEFT, padx=2)
        ttk.Button(code_controls, text="💾 Save Sketch", 
                  command=self.export_bednii_esp).pack(side=tk.LEFT, padx=2)
        
        code_container = ttk.Frame(code_frame)
        code_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.code_text = scrolledtext.ScrolledText(code_container, wrap=tk.WORD, 
                                                  font=('Consolas', 9))
        self.code_text.pack(fill=tk.BOTH, expand=True)
        
        self.update_arduino_code()
    
    def _bind_mouse(self, event):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _unbind_mouse(self, event):
        self.canvas.unbind_all("<MouseWheel>")

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    
    def setup_components_section(self):
        comp_frame = tk.LabelFrame(self.scrollable_frame, text="🍷 Python Bar Components", 
                                  bg=self.colors['bg'], fg=self.colors['primary'],
                                  font=('Arial', 10, 'bold'), padx=8, pady=8)
        comp_frame.pack(fill=tk.X, padx=5, pady=3)
        
        comp_grid = tk.Frame(comp_frame, bg=self.colors['bg'])
        comp_grid.pack(fill=tk.X)
        
        components = [
            ("💬 Sanchez Quote", "text", self.colors['primary']),
            ("🏴‍☠️ Header", "header", self.colors['primary']),
            ("🥃 Special Offer", "quote", self.colors['secondary']),
            ("📜 Bar Menu", "list", self.colors['secondary']),
            ("🍺 Order", "button", self.colors['accent']),
            ("💸 Tips", "support", self.colors['accent'])
        ]
        
        for i, (text, comp_type, color) in enumerate(components):
            row = i // 2
            col = i % 2
            
            btn = tk.Button(comp_grid, text=text, bg=color, fg='#000000',
                          font=('Arial', 9), relief='raised', height=2,
                          command=lambda ct=comp_type: self.add_component(ct))
            btn.grid(row=row, column=col, sticky='ew', padx=2, pady=2)
        
        comp_grid.columnconfigure(0, weight=1)
        comp_grid.columnconfigure(1, weight=1)
    
    def setup_color_picker(self):
        color_frame = tk.LabelFrame(self.scrollable_frame, text="🎨 Bar Color Scheme",
                                   bg=self.colors['bg'], fg=self.colors['primary'],
                                   font=('Arial', 10, 'bold'), padx=8, pady=8)
        color_frame.pack(fill=tk.X, padx=5, pady=3)
        
        colors_grid = tk.Frame(color_frame, bg=self.colors['bg'])
        colors_grid.pack(fill=tk.X)
        
        color_options = [
            ('Background', 'bg'),
            ('Primary Color', 'primary'),
            ('Secondary', 'secondary'), 
            ('Accent', 'accent'),
            ('Text', 'text')
        ]
        
        for i, (label, color_key) in enumerate(color_options):
            btn_frame = tk.Frame(colors_grid, bg=self.colors['bg'])
            btn_frame.pack(fill=tk.X, pady=2)
            
            tk.Label(btn_frame, text=label, bg=self.colors['bg'], fg=self.colors['text'],
                    font=('Arial', 8), width=15, anchor='w').pack(side=tk.LEFT)
            
            color_btn = tk.Button(btn_frame, text='▓▓▓', bg=self.colors[color_key], fg='white',
                                font=('Arial', 8), relief='solid',
                                command=lambda ck=color_key: self.choose_color(ck))
            color_btn.pack(side=tk.LEFT, padx=5)
    
    def setup_content_editor(self):
        editor_frame = tk.LabelFrame(self.scrollable_frame, text="✏️ Bar Structure",
                                    bg=self.colors['bg'], fg=self.colors['primary'],
                                    font=('Arial', 10, 'bold'), padx=8, pady=8)
        editor_frame.pack(fill=tk.X, padx=5, pady=3)
        
        list_frame = tk.Frame(editor_frame, bg=self.colors['bg'])
        list_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(list_frame, text="Bar Components:", 
                bg=self.colors['bg'], fg=self.colors['text'],
                font=('Arial', 9)).pack(anchor='w')
        
        self.content_list = tk.Listbox(list_frame, height=6, font=('Arial', 9),
                                      bg='#1a1a1a', fg=self.colors['text'],
                                      selectbackground=self.colors['primary'])
        self.content_list.pack(fill=tk.X, pady=5)
        self.content_list.bind('<<ListboxSelect>>', self.on_content_select)
        
        btn_frame = tk.Frame(editor_frame, bg=self.colors['bg'])
        btn_frame.pack(fill=tk.X)
        
        buttons = [
            ("✏️ Edit", self.edit_selected, self.colors['secondary']),
            ("🗑️ Delete", self.delete_selected, '#8b0000'),
            ("⬆️ Up", self.move_up, self.colors['accent']),
            ("⬇️ Down", self.move_down, self.colors['accent']),
            ("🧹 Clear All", self.clear_all, '#8b0000')
        ]
        
        for text, command, color in buttons:
            btn = tk.Button(btn_frame, text=text, bg=color, fg='white',
                          font=('Arial', 8), command=command)
            btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=1)
    
    def setup_export_section(self):
        export_frame = tk.LabelFrame(self.scrollable_frame, text="📤 Project Export",
                                    bg=self.colors['bg'], fg=self.colors['primary'],
                                    font=('Arial', 10, 'bold'), padx=8, pady=8)
        export_frame.pack(fill=tk.X, padx=5, pady=3)
        
        next_num = self.get_next_bednii_number()
        info_frame = tk.Frame(export_frame, bg=self.colors['bg'])
        info_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(info_frame, text=f"Next sketch: bednii_esp{next_num}.ino",
                bg=self.colors['bg'], fg=self.colors['text'],
                font=('Arial', 10, 'bold')).pack()
        
        path_frame = tk.Frame(export_frame, bg=self.colors['bg'])
        path_frame.pack(fill=tk.X, pady=3)
        
        tk.Label(path_frame, text=f"Path: {self.export_path}",
                bg=self.colors['bg'], fg=self.colors['text'],
                font=('Arial', 8), anchor='w').pack(fill=tk.X)
        
        tk.Button(path_frame, text="📁 Change Export Path", 
                 command=self.change_export_path,
                 bg=self.colors['secondary'], fg='white', font=('Arial', 8)).pack(pady=2)
        
        export_btn = tk.Button(export_frame, text="⚡ CREATE ARDUINO SKETCH", 
                              bg=self.colors['accent'], fg='white',
                              font=('Arial', 11, 'bold'), height=2,
                              command=self.export_bednii_esp)
        export_btn.pack(fill=tk.X, pady=5)
        
        extra_btn_frame = tk.Frame(export_frame, bg=self.colors['bg'])
        extra_btn_frame.pack(fill=tk.X)
        
        tk.Button(extra_btn_frame, text="⚙️ WiFi Settings", command=self.setup_wifi,
                 bg=self.colors['secondary'], fg='white', font=('Arial', 9)).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=1)
        tk.Button(extra_btn_frame, text="💾 Save Project", command=self.save_project,
                 bg=self.colors['primary'], fg='white', font=('Arial', 9)).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=1)
        
        support_frame = tk.Frame(export_frame, bg=self.colors['bg'])
        support_frame.pack(fill=tk.X, pady=(10, 0))
        
        portal_frame = tk.Frame(support_frame, bg=self.colors['bg'])
        portal_frame.pack(fill=tk.X, pady=2)
        portal_label = tk.Label(portal_frame, text="portalpma.ru", 
                          bg=self.colors['bg'], fg=self.colors['text'],
                          font=('Arial', 8), cursor="hand2")
        portal_label.pack()
        portal_label.bind("<Button-1>", lambda e: webbrowser.open("http://portalpma.ru"))
        
        telegram_frame = tk.Frame(support_frame, bg=self.colors['bg'])
        telegram_frame.pack(fill=tk.X, pady=2)
        telegram_label = tk.Label(telegram_frame, text="@Tehnofrikk", 
                            bg=self.colors['bg'], fg=self.colors['text'],
                            font=('Arial', 8), cursor="hand2")
        telegram_label.pack()
        telegram_label.bind("<Button-1>", lambda e: webbrowser.open("https://t.me/Tehnofrikk"))
        
        donate_frame = tk.Frame(support_frame, bg=self.colors['bg'])
        donate_frame.pack(fill=tk.X, pady=2)
        donate_btn = tk.Button(donate_frame, text="Support Project", 
                          bg='#2F4F4F', fg='white', font=('Arial', 8),
                          command=lambda: webbrowser.open("https://tips.yandex.ru/guest/payment/3441944"))
        donate_btn.pack()
        
        self.update_content_list()
    
    def change_export_path(self):
        new_path = filedialog.askdirectory(initialdir=self.export_path)
        if new_path:
            self.export_path = new_path
            self.save_config()
            messagebox.showinfo("Path Changed", f"Sketches will be saved to:\n{self.export_path}")
    
    def choose_color(self, color_key):
        color_code = colorchooser.askcolor(initialcolor=self.colors[color_key])[1]
        if color_code:
            self.colors[color_key] = color_code
            self.save_config()
            self.update_preview()
            self.update_arduino_code()
    
    def add_component(self, component_type):
        text = self.get_default_text(component_type)
        
        edit_window = tk.Toplevel(self.root)
        edit_window.title(f"Add {component_type}")
        edit_window.geometry("400x350")
        edit_window.configure(bg=self.colors['bg'])
        edit_window.transient(self.root)
        edit_window.grab_set()
        
        title_frame = tk.Frame(edit_window, bg=self.colors['bg'])
        title_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(title_frame, text=f"{component_type} content:", 
                bg=self.colors['bg'], fg=self.colors['text'],
                font=('Arial', 11, 'bold')).pack(side=tk.LEFT)
        
        paste_btn = tk.Button(title_frame, text="📋 Paste", 
                             command=lambda: self.paste_from_clipboard_simple(text_widget),
                             bg=self.colors['secondary'], fg='white', font=('Arial', 9))
        paste_btn.pack(side=tk.RIGHT)
        
        text_widget = scrolledtext.ScrolledText(edit_window, height=12, wrap=tk.WORD, 
                                              font=('Arial', 10), bg='#1a1a1a', fg=self.colors['text'])
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        text_widget.insert('1.0', text)
        
        def save_component():
            content = text_widget.get('1.0', tk.END).strip()
            if content:
                component = {
                    "type": component_type,
                    "text": content
                }
                self.current_content.append(component)
                self.save_config()
                self.update_content_list()
                self.update_preview()
                self.update_arduino_code()
                edit_window.destroy()
                messagebox.showinfo("Success", "Component added! Sanchez approves.")
        
        btn_frame = tk.Frame(edit_window, bg=self.colors['bg'])
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Button(btn_frame, text="💾 Save", command=save_component,
                 bg=self.colors['primary'], fg='white', font=('Arial', 10)).pack(side=tk.RIGHT, padx=5)
        tk.Button(btn_frame, text="❌ Cancel", command=edit_window.destroy,
                 bg='#333333', fg='white', font=('Arial', 10)).pack(side=tk.RIGHT, padx=5)
    
    def paste_from_clipboard_simple(self, text_widget):
        try:
            text_widget.event_generate('<<Paste>>')
        except Exception as e:
            messagebox.showerror("Error", f"Failed to paste from clipboard: {e}")
    
    def get_default_text(self, component_type):
        defaults = {
            'text': '"Life is like a box of whiskey. Expensive shit that gives you a headache."',
            'header': 'Python Bar',
            'quote': "Today's Special: Sanchez's Cynicism Whiskey",
            'list': 'Python Whiskey - $5\nDjango Vodka - $4\nFlask Pinot Grid-io - $3\nTensorFlow Tequila - $6',
            'button': 'Order Drinks',
            'support': 'Leave a tip for the bartender'
        }
        return defaults.get(component_type, 'New component')
    
    def update_content_list(self):
        self.content_list.delete(0, tk.END)
        for i, component in enumerate(self.current_content):
            emoji = {"header": "🏴‍☠️", "text": "💬", "button": "🍺", "list": "📜", 
                    "quote": "🥃", "support": "💸"}
            display_text = f"{i+1}. {emoji.get(component['type'], '📄')} {component['text'][:40]}..."
            self.content_list.insert(tk.END, display_text)
    
    def on_content_select(self, event):
        pass
    
    def edit_selected(self):
        selection = self.content_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Select a component to edit")
            return
        
        index = selection[0]
        component = self.current_content[index]
        
        edit_window = tk.Toplevel(self.root)
        edit_window.title(f"Edit {component['type']}")
        edit_window.geometry("400x350")
        edit_window.configure(bg=self.colors['bg'])
        
        title_frame = tk.Frame(edit_window, bg=self.colors['bg'])
        title_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(title_frame, text="Edit text:", 
                bg=self.colors['bg'], fg=self.colors['text'],
                font=('Arial', 11, 'bold')).pack(side=tk.LEFT)
        
        paste_btn = tk.Button(title_frame, text="📋 Paste", 
                             command=lambda: self.paste_from_clipboard_simple(text_widget),
                             bg=self.colors['secondary'], fg='white', font=('Arial', 9))
        paste_btn.pack(side=tk.RIGHT)
        
        text_widget = scrolledtext.ScrolledText(edit_window, height=12, wrap=tk.WORD, 
                                              font=('Arial', 10), bg='#1a1a1a', fg=self.colors['text'])
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        text_widget.insert('1.0', component['text'])
        
        def save_edit():
            content = text_widget.get('1.0', tk.END).strip()
            if content:
                self.current_content[index]['text'] = content
                self.save_config()
                self.update_content_list()
                self.update_preview()
                self.update_arduino_code()
                edit_window.destroy()
                messagebox.showinfo("Success", "Component updated!")
        
        btn_frame = tk.Frame(edit_window, bg=self.colors['bg'])
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Button(btn_frame, text="💾 Save", command=save_edit,
                 bg=self.colors['primary'], fg='white', font=('Arial', 10)).pack(side=tk.RIGHT, padx=5)
        tk.Button(btn_frame, text="❌ Cancel", command=edit_window.destroy,
                 bg='#333333', fg='white', font=('Arial', 10)).pack(side=tk.RIGHT, padx=5)
    
    def delete_selected(self):
        selection = self.content_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Select a component to delete")
            return
        
        index = selection[0]
        if messagebox.askyesno("Confirm", "Throw out this component?"):
            del self.current_content[index]
            self.save_config()
            self.update_content_list()
            self.update_preview()
            self.update_arduino_code()
    
    def move_up(self):
        selection = self.content_list.curselection()
        if selection and selection[0] > 0:
            index = selection[0]
            self.current_content[index], self.current_content[index-1] = self.current_content[index-1], self.current_content[index]
            self.save_config()
            self.update_content_list()
            self.content_list.select_set(index-1)
            self.update_preview()
            self.update_arduino_code()
    
    def move_down(self):
        selection = self.content_list.curselection()
        if selection and selection[0] < len(self.current_content) - 1:
            index = selection[0]
            self.current_content[index], self.current_content[index+1] = self.current_content[index+1], self.current_content[index]
            self.save_config()
            self.update_content_list()
            self.content_list.select_set(index+1)
            self.update_preview()
            self.update_arduino_code()
    
    def setup_wifi(self):
        wifi_window = tk.Toplevel(self.root)
        wifi_window.title("WiFi Settings")
        wifi_window.geometry("350x250")
        wifi_window.configure(bg=self.colors['bg'])
        
        tk.Label(wifi_window, text="Network SSID:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor=tk.W, pady=(10,0))
        ssid_entry = tk.Entry(wifi_window, font=('Arial', 10), bg='#1a1a1a', fg=self.colors['text'])
        ssid_entry.pack(fill=tk.X, padx=10, pady=2)
        ssid_entry.insert(0, self.wifi_config['ssid'])
        
        tk.Label(wifi_window, text="Password:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor=tk.W)
        pass_entry = tk.Entry(wifi_window, show="*", font=('Arial', 10), bg='#1a1a1a', fg=self.colors['text'])
        pass_entry.pack(fill=tk.X, padx=10, pady=2)
        pass_entry.insert(0, self.wifi_config['password'])
        
        ip_frame = tk.Frame(wifi_window, bg=self.colors['bg'])
        ip_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.use_dhcp = tk.BooleanVar(value=self.wifi_config.get('use_dhcp', False))
        dhcp_check = tk.Checkbutton(ip_frame, text="Use DHCP", variable=self.use_dhcp,
                                   bg=self.colors['bg'], fg=self.colors['text'], selectcolor='#1a1a1a',
                                   command=self.toggle_ip_entry)
        dhcp_check.pack(anchor=tk.W)
        
        tk.Label(wifi_window, text="ESP IP Address:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor=tk.W)
        self.ip_entry = tk.Entry(wifi_window, font=('Arial', 10), bg='#1a1a1a', fg=self.colors['text'])
        self.ip_entry.pack(fill=tk.X, padx=10, pady=2)
        self.ip_entry.insert(0, self.wifi_config['ip'])
        
        self.toggle_ip_entry()
        
        def save_wifi():
            self.wifi_config['ssid'] = ssid_entry.get()
            self.wifi_config['password'] = pass_entry.get()
            self.wifi_config['ip'] = self.ip_entry.get()
            self.wifi_config['use_dhcp'] = self.use_dhcp.get()
            self.save_config()
            self.update_arduino_code()
            wifi_window.destroy()
            messagebox.showinfo("Saved", "WiFi settings updated\nSanchez nods grimly")
        
        tk.Button(wifi_window, text="💾 Save", command=save_wifi,
                 bg=self.colors['primary'], fg='white', font=('Arial', 10)).pack(pady=10)
    
    def toggle_ip_entry(self):
        if self.use_dhcp.get():
            self.ip_entry.config(state='disabled', bg='#333333')
        else:
            self.ip_entry.config(state='normal', bg='#1a1a1a')
    
    def update_preview(self):
        html_content = self.generate_html()
        self.preview_text.delete('1.0', tk.END)
        self.preview_text.insert('1.0', html_content)
    
    def open_in_browser(self):
        html_content = self.generate_html()
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', suffix='.html', delete=False) as f:
            f.write(html_content)
            temp_file = f.name
        
        webbrowser.open(f'file://{temp_file}')
        messagebox.showinfo("Opened", "Python Bar opened in browser\nThe bartender is waiting for orders...")
    
    def save_html_file(self):
        filename = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("HTML files", "*.html"), ("All files", "*.*")]
        )
        if filename:
            html_content = self.generate_html()
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(html_content)
            messagebox.showinfo("Saved", f"Bar menu saved: {filename}")
    
    def update_arduino_code(self):
        code = self.generate_arduino_sketch()
        self.code_text.delete('1.0', tk.END)
        self.code_text.insert('1.0', code)
    
    def save_project(self):
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            self.save_config()
            messagebox.showinfo("Saved", f"Project saved: {filename}\nSanchez mutters something unintelligible")
    
    def clear_all(self):
        if messagebox.askyesno("Clear", "Throw out ALL bar components?"):
            self.current_content = []
            self.save_config()
            self.update_content_list()
            self.update_preview()
            self.update_arduino_code()
    
    def get_next_bednii_number(self):
        pattern = os.path.join(self.export_path, "bednii_esp*.ino")
        existing_files = glob.glob(pattern)
        max_num = 0
        for f in existing_files:
            try:
                num = int(os.path.basename(f).replace("bednii_esp", "").replace(".ino", ""))
                if num > max_num:
                    max_num = num
            except:
                continue
        return max_num + 1
    
    def export_bednii_esp(self):
        next_num = self.get_next_bednii_number()
        filename = f"bednii_esp{next_num}.ino"
        full_path = os.path.join(self.export_path, filename)
        
        code = self.generate_arduino_sketch()
        
        try:
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(code)
            messagebox.showinfo("Export Complete", 
                              f"Sketch saved: {full_path}\n\n"
                              f"Upload it to ESP8266 and open IP in browser.\n"
                              f"Python Bar is ready to work...")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save sketch: {e}")
    
    def generate_html(self):
        html_parts = []
        
        html_parts.append(f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Python Bar</title>
            <style>
                body {{
                    background-color: {self.colors['bg']};
                    color: {self.colors['text']};
                    font-family: 'Georgia', serif;
                    margin: 0;
                    padding: 20px;
                    line-height: 1.6;
                }}
                .container {{
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                .header {{
                    text-align: center;
                    border-bottom: 2px solid {self.colors['primary']};
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }}
                .header h1 {{
                    color: {self.colors['primary']};
                    font-size: 2.5em;
                    margin: 0;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
                }}
                .quote {{
                    background: {self.colors['secondary']};
                    padding: 15px;
                    margin: 20px 0;
                    border-left: 4px solid {self.colors['accent']};
                    font-style: italic;
                }}
                .menu {{
                    background: rgba(139, 0, 0, 0.1);
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 5px;
                }}
                .menu-item {{
                    margin: 10px 0;
                    padding: 8px;
                    border-bottom: 1px solid {self.colors['secondary']};
                }}
                .button {{
                    background: {self.colors['accent']};
                    color: white;
                    padding: 12px 24px;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                    font-size: 1.1em;
                    margin: 10px 0;
                    display: inline-block;
                    text-decoration: none;
                }}
                .button:hover {{
                    background: {self.colors['primary']};
                }}
                .support {{
                    text-align: center;
                    margin-top: 30px;
                    padding: 20px;
                    background: rgba(178, 34, 34, 0.1);
                    border-radius: 5px;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 1px solid {self.colors['secondary']};
                    color: {self.colors['secondary']};
                    font-size: 0.9em;
                }}
            </style>
        </head>
        <body>
            <div class="container">
        """)
        
        for component in self.current_content:
            if component['type'] == 'header':
                html_parts.append(f'<div class="header"><h1>{component["text"]}</h1></div>')
            elif component['type'] == 'text':
                html_parts.append(f'<div class="quote">{component["text"]}</div>')
            elif component['type'] == 'quote':
                html_parts.append(f'<div class="quote" style="background: {self.colors["primary"]}20;">{component["text"]}</div>')
            elif component['type'] == 'list':
                items = component['text'].split('\n')
                menu_html = '<div class="menu">'
                for item in items:
                    if item.strip():
                        menu_html += f'<div class="menu-item">{item.strip()}</div>'
                menu_html += '</div>'
                html_parts.append(menu_html)
            elif component['type'] == 'button':
                html_parts.append(f'<a href="#" class="button" onclick="alert(\'Order accepted. Sanchez nods grimly.\')">{component["text"]}</a>')
            elif component['type'] == 'support':
                html_parts.append(f'<div class="support">{component["text"]}</div>')
        
        html_parts.append("""
                <div class="footer">
                    Python Bar • From Sanchez with cynicism
                </div>
            </div>
        </body>
        </html>
        """)
        
        return '\n'.join(html_parts)
    
    def generate_arduino_sketch(self):
        html_content = self.generate_html()
        html_content_escaped = html_content.replace('"', '\\"').replace('\n', '\\n')
        
        wifi_setup = ""
        if self.wifi_config.get('use_dhcp', False):
            wifi_setup = f"""
  WiFi.begin("{self.wifi_config['ssid']}", "{self.wifi_config['password']}");
  while (WiFi.status() != WL_CONNECTED) {{
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }}
  Serial.println("Connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());"""
        else:
            wifi_setup = f"""
  WiFi.begin("{self.wifi_config['ssid']}", "{self.wifi_config['password']}");
  WiFi.config(IPAddress({', '.join(self.wifi_config['ip'].split('.'))}));
  while (WiFi.status() != WL_CONNECTED) {{
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }}
  Serial.println("Connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());"""
        
        code = f"""
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

ESP8266WebServer server(80);

const char* html_content = "{html_content_escaped}";

void setup() {{
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("Starting Python Bar...");
{wifi_setup}
  
  server.on("/", []() {{
    server.send(200, "text/html; charset=utf-8", html_content);
  }});
  
  server.on("/order", []() {{
    server.send(200, "text/plain", "Order accepted. Sanchez nods grimly.");
  }});
  
  server.on("/support", []() {{
    server.send(200, "text/plain", "Tips received. Sanchez smirks.");
  }});
  
  server.begin();
  Serial.println("HTTP server started");
  Serial.println("Python Bar is ready!");
}}

void loop() {{
  server.handleClient();
}}
"""
        return code
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = ESP8266SiteBuilder()
    app.run()